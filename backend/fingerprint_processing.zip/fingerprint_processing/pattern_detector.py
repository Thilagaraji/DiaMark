import cv2
import numpy as np
from fingerprint_enhancer import enhance_fingerprint


# ✅ STEP 1: SEGMENTATION (REMOVE BACKGROUND NOISE)
def segment_fingerprint(img, block_size=16, threshold=15):
    rows, cols = img.shape
    mask = np.zeros_like(img)

    for i in range(0, rows - block_size, block_size):
        for j in range(0, cols - block_size, block_size):

            block = img[i:i + block_size, j:j + block_size]

            if np.std(block) > threshold:
                mask[i:i + block_size, j:j + block_size] = 1

    return img * mask


# ✅ STEP 2: GRADIENT COMPUTATION
def compute_gradients(img):
    gx = cv2.Sobel(img, cv2.CV_64F, 1, 0, ksize=3)
    gy = cv2.Sobel(img, cv2.CV_64F, 0, 1, ksize=3)
    return gx, gy


# ✅ STEP 3: ORIENTATION FIELD
def get_orientation_field(img, block_size=16):
    rows, cols = img.shape
    orientation = np.zeros((rows // block_size, cols // block_size))

    gx, gy = compute_gradients(img)

    for i in range(0, rows - block_size, block_size):
        for j in range(0, cols - block_size, block_size):

            gxi = gx[i:i + block_size, j:j + block_size]
            gyi = gy[i:i + block_size, j:j + block_size]

            v_x = 2 * np.sum(gxi * gyi)
            v_y = np.sum(gxi**2 - gyi**2)

            angle = 0.5 * np.arctan2(v_x, v_y)

            orientation[i // block_size, j // block_size] = angle

    return orientation


# ✅ STEP 4: SMOOTH ORIENTATION (IMPORTANT FIX)
def smooth_orientation(orientation):
    orientation = cv2.GaussianBlur(orientation, (3, 3), 0)
    return orientation


# ✅ STEP 5: ANALYZE DISTRIBUTION
def analyze_orientation_distribution(orientation):
    angles = np.degrees(orientation).flatten()

    # Normalize angles to 0–180
    angles = np.mod(angles, 180)

    mean_angle = np.mean(angles)
    std_angle = np.std(angles)

    return mean_angle, std_angle


# ✅ STEP 6: FINAL CLASSIFICATION (STABLE)
def classify_pattern(orientation):

    angles = np.degrees(orientation)

    angles = np.abs(angles)

    std = np.std(angles)
    mean = np.mean(angles)

    print("Mean:", mean)
    print("STD:", std)

    # =========================
    # IMPROVED CLASSIFICATION
    # =========================

    # ARCH:
    # low curvature
    # smoother ridge flow

    if std < 40 and mean < 65:
        return "Arch"

    # LOOP:
    # medium curvature

    elif 40 <= std < 75:
        return "Loop"

    # WHORL:
    # circular/high variation

    else:
        return "Whorl"

# ✅ FINAL PIPELINE (USE THIS)
def detect_pattern(img):
    """
    Final fingerprint pattern detection pipeline
    Input: preprocessed grayscale image (numpy array)
    """

    #  1. Enhance ridges
    enhanced = enhance_fingerprint(img)
    enhanced = (enhanced * 255).astype(np.uint8)

    #  2. Remove background noise
    segmented = segment_fingerprint(enhanced)

    #  3. Orientation field
    orientation = get_orientation_field(segmented)

    #  4. Smooth orientation (CRITICAL)
    orientation = smooth_orientation(orientation)

    #  5. Analyze
    mean_angle, std_angle = analyze_orientation_distribution(orientation)

    print("Mean Orientation:", mean_angle)
    print("Std Orientation:", std_angle)

    #  6. Classify
    pattern = classify_pattern(std_angle)

    return pattern